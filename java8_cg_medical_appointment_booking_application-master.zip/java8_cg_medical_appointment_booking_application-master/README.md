This is a Java 8 project on Medical Appointment Booking System. It uses lambda expressions and stream api.
