package com.cg.medical_appointment_booking_java8;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.cg.model.*;
import com.cg.exceptions.InvalidAppointmentException;

/**
 * <p>AppointmentTest is a test class for the Appointment class.</p>
 * 
 * <p>It contains unit tests to verify the functionality of the Appointment class,
 * including appointment creation, completion, and status checks.</p>
 * 
 * <p>Example usage:</p>
 * <pre>
 * AppointmentTest appointmentTest = new AppointmentTest();
 * appointmentTest.testAppointmentCreationSuccess();
 * </pre>
 */
public class AppointmentTest {

    private Patient patient;
    private Doctor doctor;

    /**
     * <p>Initializes test data:</p>
     * <ul>
     *   <li>Patient with ID "1" and name "Somrik Dinda"</li>
     *   <li>Doctor with ID "1" and name "Soham Das"</li>
     * </ul>
     */
    @BeforeEach
    public void setUp() {
        patient = new Patient("1", "Somrik Dinda");
        doctor = new Doctor("1", "Soham Das");
    }

    /**
     * <p>Test case: Create an appointment successfully.</p>
     * 
     * <p>Expected result:</p>
     * <ul>
     *   <li>Appointment should be created with the correct patient, doctor, and status.</li>
     *   <li>Doctor should be set as unavailable after appointment.</li>
     * </ul>
     */
    @Test
    public void testAppointmentCreationSuccess() {
        try {
            Appointment appointment = new Appointment(patient, doctor);
            assertNotNull(appointment);
            assertEquals(patient, appointment.getPatient().orElse(null));
            assertEquals(doctor, appointment.getDoctor().orElse(null));
            assertEquals("Scheduled", appointment.getStatus());
            assertFalse(doctor.isAvailable());
        } catch (InvalidAppointmentException e) {
            fail("Exception should not be thrown when doctor is available");
        }
    }

    /**
     * <p>Test case: Complete an appointment successfully.</p>
     * 
     * <p>Expected result:</p>
     * <ul>
     *   <li>Appointment status should be updated to "Completed".</li>
     *   <li>Doctor should be set as available after appointment completion.</li>
     * </ul>
     */
    @Test
    public void testCompleteAppointment() {
        try {
            Appointment appointment = new Appointment(patient, doctor);
            appointment.completeAppointment();
            assertEquals("Completed", appointment.getStatus());
            assertTrue(doctor.isAvailable());
        } catch (InvalidAppointmentException e) {
            fail("Exception should not be thrown when doctor is available");
        }
    }
}
