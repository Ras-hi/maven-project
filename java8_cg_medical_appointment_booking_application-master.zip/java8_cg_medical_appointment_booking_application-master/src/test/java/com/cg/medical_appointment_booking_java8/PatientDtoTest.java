package com.cg.medical_appointment_booking_java8;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.dto.PatientDto;

import static org.junit.jupiter.api.Assertions.*;

/**
 * PatientDtoTest is a test class for the PatientDto class.
 * It contains unit tests to verify the functionality of the PatientDto class,
 * including constructor, getters, and the showProfile method.
 */
class PatientDtoTest {

    private PatientDto patient;

    /**
     * Sets up the test environment by creating a PatientDto instance
     * before each test case.
     */
    @BeforeEach
    void setUp() {
        patient = new PatientDto("Soham Das");
    }

    /**
     * Tests the constructor and getter methods of the PatientDto class.
     * <p>Expected result: The name should be "Soham Das".</p>
     */
    @Test
    void testConstructorAndGetters() {
        assertEquals("Soham Das", patient.getName());
    }

    /**
     * Tests the setName method of the PatientDto class.
     * <p>Expected result: The name should remain "Soham Das" after setting it to the same value.</p>
     */
    @Test
    void testSetName() {
        patient.setName("Soham Das");
        assertEquals("Soham Das", patient.getName());
    }

    /**
     * Tests the showProfile method of the PatientDto class.
     * <p>Expected result: The output should match the expected string representation of the PatientDto.</p>
     */
    @Test
    void testShowProfile() {
        final java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(outContent));

        patient.showProfile();

        String expectedOutput = "Patient's name: Soham Das";
        assertEquals(expectedOutput, outContent.toString().trim());

        // Reset the standard output
        System.setOut(System.out);
    }
}
