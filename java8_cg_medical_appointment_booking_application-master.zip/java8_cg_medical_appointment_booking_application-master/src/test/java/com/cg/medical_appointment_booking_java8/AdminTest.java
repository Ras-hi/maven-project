package com.cg.medical_appointment_booking_java8;

import com.cg.annotations.Security;
import com.cg.model.Admin;
import com.cg.model.Doctor;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * AdminTest is a test class for the Admin class.
 * It contains unit tests to verify the functionality of the Admin class,
 * including removing doctors and checking security annotations.
 * 
 * <p>Example usage:</p>
 * <pre>
 * AdminTest adminTest = new AdminTest();
 * adminTest.testRemoveDoctorSuccess();
 * </pre>
 */
public class AdminTest {

    private Admin admin;
    private List<Doctor> doctorList;

    /**
     * Sets up the test environment by creating an Admin instance and 
     * initializing a list of doctors for testing.
     */
    @BeforeEach
    public void setUp() {
        // Create Admin instance
        admin = new Admin("1", "Soham", "adminPass");

        // Prepare a dummy doctor list
        doctorList = new ArrayList<>();
        doctorList.add(new Doctor("1", "Dr. Somrik"));
        doctorList.add(new Doctor("2", "Dr. Abhilash"));
    }

    /**
     * Tests the successful removal of a doctor from the list.
     * <p>Expected result: Doctor with ID "1" should be removed from the list.</p>
     */
    @Test
    public void testRemoveDoctorSuccess() {
        admin.removeDoctor(doctorList, "1");

        // Ensure the doctor is removed
        assertEquals(1, doctorList.size());
        assertFalse(doctorList.stream().anyMatch(d -> d.getId().equals("1")));
    }

    /**
     * Tests the attempt to remove a doctor that does not exist in the list.
     * <p>Expected result: The list should remain unchanged and the size should be 2.</p>
     */
    @Test
    public void testRemoveDoctorNotFound() {
        admin.removeDoctor(doctorList, "999");

        // List should remain unchanged
        assertEquals(2, doctorList.size());
    }

    /**
     * Tests whether the Admin class has the @Security annotation with role = Admin.
     * <p>Expected result: The Admin class should be annotated with @Security and the role should be "Admin".</p>
     */
    @Test
    public void testSecurityAnnotationPresent() {
        // Ensure the Admin class has @Security annotation with role = Admin
        assertTrue(admin.getClass().isAnnotationPresent(Security.class));
        Security sec = admin.getClass().getAnnotation(Security.class);
        assertEquals("Admin", sec.role());
    }
}
