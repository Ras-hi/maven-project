package com.cg.medical_appointment_booking_java8;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.model.Patient;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

/**
 * <p>PatientTest is a test class for the Patient class.</p>
 * 
 * <p>It contains unit tests to verify the functionality of the Patient class,
 * including constructor, getters, setters, and showProfile method.</p>
 * 
 * <p>Example usage:</p>
 * <pre>
 * PatientTest patientTest = new PatientTest();
 * patientTest.testConstructorAndGetters();
 * </pre>
 */
public class PatientTest {

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    private Patient patient;

    /**
     * <p>Initializes test data.</p>
     * <ul>
     *   <li>Patient with ID "1"</li>
     *   <li>Name "Rashi"</li>
     * </ul>
     */
    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outContent));
        patient = new Patient("1", "Rashi");
    }

    /**
     * <p>Restores the original system output after each test.</p>
     */
    @AfterEach
    public void tearDown() {
        System.setOut(originalOut);
    }

    /**
     * <p>Test case: Verify the constructor and getter methods.</p>
     * 
     * <p>Expected result:</p>
     * <ul>
     *   <li>Patient should be initialized with the correct ID and name.</li>
     * </ul>
     */
    @Test
    public void testConstructorAndGetters() {
        assertEquals("1", patient.getId());
        assertEquals("Rashi", patient.getName());
    }

    /**
     * <p>Test case: Verify the setId and setName methods.</p>
     * 
     * <p>Expected result:</p>
     * <ul>
     *   <li>Patient ID should be updated correctly.</li>
     *   <li>Patient name should be updated correctly.</li>
     * </ul>
     */
    @Test
    public void testSetters() {
        patient.setId("2");
        patient.setName("Soham");
        assertEquals("2", patient.getId());
        assertEquals("Soham", patient.getName());
    }

    /**
     * <p>Test case: Verify the showProfile method.</p>
     * 
     * <p>Expected result:</p>
     * <ul>
     *   <li>Patient profile information should be printed correctly.</li>
     * </ul>
     */
    @Test
    public void testShowProfile() {
        patient.showProfile();
        String expectedOutput = "Patient's id: 1, name: Rashi" + System.lineSeparator();
        assertEquals(expectedOutput, outContent.toString());
    }
}
