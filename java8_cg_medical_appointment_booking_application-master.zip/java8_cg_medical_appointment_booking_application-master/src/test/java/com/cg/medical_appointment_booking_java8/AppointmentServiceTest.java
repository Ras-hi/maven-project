package com.cg.medical_appointment_booking_java8;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

import com.cg.dto.DoctorDto;
import com.cg.dto.PatientDto;
import com.cg.model.Appointment;
import com.cg.model.Patient;
import com.cg.service.AppointmentSystem;

/**
 * AppointmentServiceTest is a test class for the AppointmentSystem class.
 * <p>
 * It contains unit tests to verify the functionality of the AppointmentSystem,
 * including registering doctors and patients, booking appointments, completing appointments,
 * and displaying information about doctors and patients.
 *
 * <p>Example usage:</p>
 * <pre>
 * AppointmentServiceTest test = new AppointmentServiceTest();
 * test.testRegisterDoctor();
 * </pre>
 */
public class AppointmentServiceTest {

    private AppointmentSystem appointmentSystem;

    /**
     * The setUp method initializes the AppointmentSystem object before each test.
     */
    @BeforeEach
    public void setUp() {
        appointmentSystem = new AppointmentSystem();
    }

    /**
     * The testRegisterDoctor method tests the registration of a doctor in the
     * appointment system. It verifies that the doctor is successfully added to the
     * system.
     */
    @Test
    public void testRegisterDoctor() {
        DoctorDto doctorDto = new DoctorDto("Uday", true);
        appointmentSystem.registerDoctor(doctorDto);
        Assertions.assertEquals(1, appointmentSystem.getDoctorList().size());
    }

    /**
     * The testRegisterPatient method tests the registration of a patient in the
     * appointment system. It verifies that the patient is successfully added to the
     * system.
     */
    @Test
    public void testRegisterPatient() {
        PatientDto patientDto = new PatientDto("Ankan Dey");
        appointmentSystem.registerPatient(patientDto);
        Assertions.assertEquals(1, appointmentSystem.getPatientList().size());
    }

    /**
     * The testBookAppointment method tests the booking of an appointment for a patient in the 
     * appointment system. It verifies that the appointment is successfully created and associated with the patient.
     */
    @Test
    public void testBookAppointment() {
        DoctorDto doctorDto = new DoctorDto("Uday", true);
        appointmentSystem.registerDoctor(doctorDto);
        PatientDto patientDto = new PatientDto("Ankan Dey");
        appointmentSystem.registerPatient(patientDto);

        Patient patient = appointmentSystem.getPatientList().get(0);
        Appointment appointment = appointmentSystem.bookAppointment(patient);

        Assertions.assertNotNull(appointment);
        Assertions.assertEquals(patient, appointment.getPatient().orElse(null));
    }

    /**
     * The testCompleteAppointment method tests the completion of an appointment in
     * the appointment system. It verifies that the appointment status is updated to
     * "Completed".
     */
    @Test
    public void testCompleteAppointment() {
        DoctorDto doctorDto = new DoctorDto("Uday", true);
        appointmentSystem.registerDoctor(doctorDto);
        PatientDto patientDto = new PatientDto("Ankan Dey");
        appointmentSystem.registerPatient(patientDto);

        Patient patient = appointmentSystem.getPatientList().get(0);
        Appointment appointment = appointmentSystem.bookAppointment(patient);

        Assertions.assertNotNull(appointment);
        appointmentSystem.completeAppointment(0);
        Assertions.assertEquals("Completed", appointment.getStatus());
    }

    /**
     * The testShowAllDoctors method tests the display of all doctors in the
     * appointment system. It verifies that the list of doctors is displayed
     * successfully.
     */
    @Test
    public void testShowAllDoctors() {
        DoctorDto doctorDto = new DoctorDto("Uday", true);
        appointmentSystem.registerDoctor(doctorDto);
        DoctorDto doctorDto2 = new DoctorDto("Soham", true);
        appointmentSystem.registerDoctor(doctorDto2);

        try {
            appointmentSystem.showAllDoctors();
        } catch (Exception e) {
            Assertions.fail("Exception thrown while showing all doctors: " + e.getMessage());
        }
    }

    /**
     * The testShowAllPatients method tests the display of all patients in the
     * appointment system. It verifies that the list of patients is displayed
     * successfully.
     */
    @Test
    public void testShowAllPatients() {
        PatientDto patientDto = new PatientDto("Ankan Dey");
        appointmentSystem.registerPatient(patientDto);
        PatientDto patientDto2 = new PatientDto("Puja Roy");
        appointmentSystem.registerPatient(patientDto2);

        try {
            appointmentSystem.showAllPatients();
        } catch (Exception e) {
            Assertions.fail("Exception thrown while showing all patients: " + e.getMessage());
        }
    }
}