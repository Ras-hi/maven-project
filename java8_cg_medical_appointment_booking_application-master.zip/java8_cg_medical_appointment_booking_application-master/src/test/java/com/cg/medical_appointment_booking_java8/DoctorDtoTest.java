package com.cg.medical_appointment_booking_java8;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.dto.DoctorDto;

import static org.junit.jupiter.api.Assertions.*;

/**
 * DoctorDtoTest is a test class for the DoctorDto class.
 * It contains unit tests to verify the functionality of the DoctorDto class,
 * including constructor, getters, setters, and the showProfile method.
 */
class DoctorDtoTest {

    private DoctorDto doctor;

    /**
     * Sets up the test environment by creating a DoctorDto instance
     * before each test case.
     */
    @BeforeEach
    void setUp() {
        doctor = new DoctorDto("Rajat", true);
    }

    /**
     * Tests the constructor and getter methods of the DoctorDto class.
     * <p>Expected result: The name should be "Rajat" and availability should be true.</p>
     */
    @Test
    void testConstructorAndGetters() {
        assertEquals("Rajat", doctor.getName());
        assertTrue(doctor.isAvailable());
    }

    /**
     * Tests the setName method of the DoctorDto class.
     * <p>Expected result: The name should be updated to "Abhilash".</p>
     */
    @Test
    void testSetName() {
        doctor.setName("Abhilash");
        assertEquals("Abhilash", doctor.getName());
    }

    /**
     * Tests the setAvailable method of the DoctorDto class.
     * <p>Expected result: The availability should be updated to false.</p>
     */
    @Test
    void testSetAvailable() {
        doctor.setAvailable(false);
        assertFalse(doctor.isAvailable());
    }

    /**
     * Tests the showProfile method of the DoctorDto class.
     * <p>Expected result: The output should match the expected string representation of the DoctorDto.</p>
     */
    @Test
    void testShowProfile() {
        final java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(outContent));

        doctor.showProfile();

        String expectedOutput = "Doctor [name=Rajat, available=true]";
        assertEquals(expectedOutput, outContent.toString().trim());

        // Reset the standard output
        System.setOut(System.out);
    }
}
