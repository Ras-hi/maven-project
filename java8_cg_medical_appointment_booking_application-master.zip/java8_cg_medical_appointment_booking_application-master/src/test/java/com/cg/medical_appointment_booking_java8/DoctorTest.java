package com.cg.medical_appointment_booking_java8;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.model.Doctor;

/**
 * <p>DoctorTest is a test class for the Doctor class.</p>
 * 
 * <p>It contains unit tests to verify the functionality of the Doctor class,
 * including constructor, getters, setters, and showProfile method.</p>
 * 
 * <p>Example usage:</p>
 * <pre>
 * DoctorTest doctorTest = new DoctorTest();
 * doctorTest.testDoctorInitialization();
 * </pre>
 */
public class DoctorTest {

    private Doctor doctor;

    /**
     * <p>Initializes test data.</p>
     * <ul>
     *   <li>Doctor with ID "1"</li>
     *   <li>Name "Dr. Rajat"</li>
     * </ul>
     */
    @BeforeEach
    public void setUp() {
        doctor = new Doctor("1", "Dr. Rajat");
    }

    /**
     * <p>Test case: Verify the constructor and getters.</p>
     * 
     * <ul>Expected result:
     *   <li>Doctor should be initialized with the correct ID and name.</li>
     *   <li>Doctor should be available by default.</li>
     * </ul>
     */
    @Test
    public void testDoctorInitialization() {
        assertEquals("1", doctor.getId());
        assertEquals("Dr. Rajat", doctor.getName());
        assertTrue(doctor.isAvailable());
    }

    /**
     * <p>Test case: Verify setting doctor availability.</p>
     * 
     * <p>Expected result:</p>
     * <ul>
     *   <li>Doctor availability should reflect false after being set to false.</li>
     *   <li>Doctor availability should reflect true after being set to true.</li>
     * </ul>
     */
    @Test
    public void testSetAvailability() {
        doctor.setAvailable(false);
        assertFalse(doctor.isAvailable());

        doctor.setAvailable(true);
        assertTrue(doctor.isAvailable());
    }

    /**
     * <p>Test case: Verify the output of the showProfile method.</p>
     * 
     * <p>Expected result:</p>
     * <ul>
     *   <li>The printed profile should match the expected string format.</li>
     * </ul>
     * 
     * <p>Note: This test captures the standard output for comparison.</p>
     */
    @Test
    public void testShowProfile() {
        java.io.ByteArrayOutputStream outContent = new java.io.ByteArrayOutputStream();
        System.setOut(new java.io.PrintStream(outContent));

        doctor.showProfile();

        String expected = "Doctor's id: 1, name: Dr. Rajat, available: true";
        assertEquals(expected.trim(), outContent.toString().trim());

        System.setOut(System.out);
    }
}
