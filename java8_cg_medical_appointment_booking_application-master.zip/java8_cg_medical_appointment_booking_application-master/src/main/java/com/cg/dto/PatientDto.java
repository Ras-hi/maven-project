package com.cg.dto;

import java.util.function.Consumer;

/**
 * PatientDto is a Data Transfer Object (DTO) that represents a patient. It
 * contains the patient's name. This class is used to transfer data between
 * different layers of the application.
 * 
 * <p>
 * Example usage:
 * </p>
 * 
 * <pre>
 * PatientDto patient = new PatientDto("John Doe");
 * System.out.println(patient.getName()); // Output: John Doe
 * </pre>
 */
public class PatientDto {

    private String name;

	/**
	 * Constructor to initialize the PatientDto object with a name.
	 * 
	 * @param name The name of the patient.
	 */
    public PatientDto(String name) {
        setName(name);
    }

	/**
	 * Gets the name of the patient.
	 * 
	 * @return The name of the patient.
	 */
    public String getName() {
        return name;
    }
    /** Sets the name of the patient.
     * 												
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Displays the profile information of the patient.
     * <p>
     * This method uses a {@code Consumer<String>} to print the patient's name
     * to the standard output.
     * </p>
     */
    public void showProfile() {
    	System.out.println("Patient's name: "+this.getName()); 
    }


}