package com.cg.dto;

/**
 * DoctorDto is a Data Transfer Object (DTO) that represents a doctor. It
 * contains the doctor's name and availability status. This class is used to
 * transfer data between different layers of the application.
 * 
 * <p>
 * Example usage:
 * </p>
 * 
 * <pre>
 * DoctorDto doctor = new DoctorDto("Dr.Somrik", true);
 * System.out.println(doctor.getName()); // Output: Dr.Somrik
 * </pre>
 */
public class DoctorDto {
    private String name;
    private boolean available;

	/**
	 * Constructor to initialize the DoctorDto object with a name and availability
	 * status.
	 * 
	 * @param name      The name of the doctor.
	 * @param available The availability status of the doctor.
	 */
    public DoctorDto(String name, boolean available) {
        setName(name);
        setAvailable(available);
    }

	/**
	 * Gets the name of the doctor.
	 * 
	 * @return The name of the doctor.
	 */
    public String getName() {
        return name;
    }
/**Sets the name of the doctor.
 * 	
 * @param name
 */
    public void setName(String name) {
        this.name = name;
    }
/** Gets the availability status of the doctor.
 * 			 
 * @return The availability status of the doctor.
 */
    public boolean isAvailable() {
        return available;
    }
    /** Sets the availability status of the doctor.
     * 				
     * @param available
     */
    public void setAvailable(boolean available) {
        this.available = available;
    }

	/**
	 * Displays the profile information of the doctor.
	 * <p>
	 * This method uses a {@code Runnable} to print the doctor's name and
	 * availability status to the standard output.
	 * </p>
	 */	
    public void showProfile() {
    	System.out.println("Doctor [name=" + name + ", available=" + available + "]");
    }

}

