package com.cg.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.dto.*;
import com.cg.exceptions.InvalidAppointmentException;
import com.cg.model.*;

/**
 * Main interface defines the methods for managing the appointment system,
 * including registering doctors and patients, booking and completing
 * appointments, and displaying information about doctors and patients.
 * 
 * <p>
 * Example usage:
 * </p>
 * 
 * <pre>
 * Main appointmentSystem = new AppointmentSystem();
 * appointmentSystem.registerDoctor(doctorDto);
 * appointmentSystem.registerPatient(patientDto);
 * </pre>
 */
public interface Main {
    /**
     * Registers a doctor in the system.
     *
     * @param doctorDto The DoctorDto object containing doctor information.
     */
    public void registerDoctor(DoctorDto doctorDto);

    /**
     * Registers a patient in the system.
     *
     * @param patientDto The PatientDto object containing patient information.
     */
    public void registerPatient(PatientDto patientDto);

    /**
     * Books an appointment for a patient.
     *
     * @param patient The Patient object for whom the appointment is to be booked.
     * @return The Appointment object created for the booking, or null if booking fails.
     */
    public Appointment bookAppointment(Patient patient);

    /**
     * Completes an appointment for a patient.
     *
     * @param index The index of the appointment to be completed.
     */
    public void completeAppointment(int index);

    /**
     * Shows all the doctors in the system.
     *
     * @throws InvalidAppointmentException If there are no registered doctors.
     */
    public void showAllDoctors();

    /**
     * Displays all appointments in the system.
     *
     * @throws InvalidAppointmentException If there are no appointments to display.
     */
    public void showAllAppointments() throws InvalidAppointmentException;

    /**
     * Shows all patients in the system.
     *
     * @throws InvalidAppointmentException If there are no registered patients.
     */
    public void showAllPatients();

    /**
     * Retrieves the list of registered patients.
     *
     * @return A list of Patient objects.
     */
    public List<Patient> getPatientList();

    /**
     * Validates the admin password.
     *
     * @param pass The password entered by the admin.
     * @param sc   The Scanner object for user input.
     */
    public void validateAdminPass(String pass, Scanner sc);
}
