package com.cg.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.dto.DoctorDto;
import com.cg.dto.PatientDto;
import com.cg.exceptions.ChoiceHandler;
import com.cg.exceptions.InvalidAppointmentException;
import com.cg.exceptions.NameHandler;
import com.cg.model.Patient;
import com.cg.service.AppointmentSystem;

/*
 * AppMain class is the main entry point of the Medical Appointment Booking System.
 * It provides a command-line interface for users to interact with the system.
 * Users can register patients and doctors, book appointments, and manage the system.
 * 
 * <p>Example usage:</p>
 * <pre>
 * public static void main(String[] args) {
 *     AppMain.main(args);
 * }
 * </pre>
 */
public class AppMain {
    public static void main(String[] args) {
        Main system = new AppointmentSystem();
        Scanner sc = new Scanner(System.in);
        while(true) {
        	try {
        		System.out.println("\nSelect one option:");
				System.out.println("1. Register Patient");
				System.out.println("2. Register Doctor");
				System.out.println("3. Book Appointment");
				System.out.println("4. Show All Doctors");
				System.out.println("5. Show All Appointments");
				System.out.println("6. Complete Appointment");
				System.out.println("7. Remove Doctor");
				System.out.println("8. Show All Patients");
				System.out.println("9. Exit");
				String choice = sc.nextLine();
				ChoiceHandler.check(choice);
				int final_choice = Integer.parseInt(choice);
				String pname = null, pid = null;
				switch(final_choice) {
					case 1:{
						try {
							boolean tempflag = true;
							int j = 1;
							while (tempflag) {
								try {
									switch (j) {
									case 1: {
										System.out.println("Enter name:");
										pname = sc.nextLine();
										NameHandler.check(pname);
										j++;
										tempflag = false;
										break;
									}
									}
								} catch (Exception e) {
									System.out.println(e.getMessage());
								}
							}
							if (j == 2) {
								system.registerPatient(new PatientDto(pname));
								break;
							} else {
								throw new InvalidAppointmentException("Patient is not created!");
							}
						} catch (Exception e) {
							System.out.println(e.getMessage());
							break;
						}
						
					}
					case 2:{
						try {
							boolean tempflag = true;
							int j = 1;
							while (tempflag) {
								try {
									switch (j) {
									case 1: {
										System.out.println("Enter name:");
										pname = sc.nextLine();
										NameHandler.check(pname);
										j++;
										tempflag = false;
										break;
									}
									}
								} catch (Exception e) {
									System.out.println(e.getMessage());
								}
							}
							if (j == 2) {
								system.registerDoctor(new DoctorDto(pname, true));
								break;
							} else {
								throw new InvalidAppointmentException("Doctor is not created!");
							}
						} catch (Exception e) {
							System.out.println(e.getMessage());
							break;
						}
						
					}
					case 3:{
						try {
							List<Patient> tempList = system.getPatientList();
							if(tempList.isEmpty()) {
								System.out.println("First add at least one patient!");
								break;
							}
							for(Patient p: tempList) {
								p.showProfile();
							}
							System.out.println("Select Patient's ID:");
							pid = sc.nextLine();
							ChoiceHandler.check(pid);
							Patient tempPatient = null;
							for(Patient p: tempList) {
								if(p.getId().compareTo(pid)==0) {
									tempPatient = p;
									break;
								}
							}
							if(tempPatient==null) {
								System.out.println("Patient not found!");
								break;
							}
							system.bookAppointment(tempPatient);
							break;
						}
						catch(Exception e) {
							System.out.println(e.getMessage());
							break;
						}
						
					}
					case 4:{
						try {
							system.showAllDoctors();
							break;
						}
						catch(Exception e) {
							System.out.println(e.getMessage());
							break;
						}
						
					}
					case 5:{
						try {
							system.showAllAppointments();
							break;
						}
						catch(Exception e) {
							System.out.println(e.getMessage());
							break;
						}
						
					}
					case 6:{
						try {
							system.showAllAppointments();
							System.out.println("Select appointment number:");
							pid = sc.nextLine();
							ChoiceHandler.check(pid);
							system.completeAppointment(Integer.parseInt(pid)-1);
							break;
						}
						catch(Exception e) {
							System.out.println(e.getMessage());
							break;
						}
						
					}
					case 7:{
						try {
							System.out.println("Enter Admin Password:");
							pid = sc.nextLine();
							NameHandler.check(pid);
							system.validateAdminPass(pid, sc);
							break;
						}
						catch(Exception e) {
							System.out.println(e.getMessage());
							break;
						}
						
					}
					case 8:{
						try {
							system.showAllPatients();
							break;
						}
						catch(Exception e) {
							System.out.println(e.getMessage());
							break;
						}
					}
					case 9:{
						System.out.println("You are Welcome!");
						System.exit(0);
						break;
					}
					default:{
						System.out.println("Input should be between 1 to 9!!");
					}
				}
        	}
        	catch(Exception e) {
        		System.out.println(e.getMessage());
        	}
        }
    }
}
