package com.cg.annotations;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;

/**
 * Annotation to specify role-based security. Can be applied to a class to
 * define required user role.
 * 
 * <p>
 * Example usage:
 * 
 * 
 * <pre>
 * &#64;Security(role = "ADMIN")
 * public class AdminService { ... }
 * </pre>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface Security {
	/**
    * Defines the role required to access the annotated type.
    * @return the required role as a string
    */
	String role();
	
}