package com.cg.exceptions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * ChoiceHandler is a utility class that provides methods to validate user
 * input. It checks if the provided choice is a valid digit.
 * 
 * <p>
 * Example usage:
 * </p>
 * 
 * <pre>
 * try {
 * 	ChoiceHandler.check("5");
 * } catch (InvalidAppointmentException e) {
 * 	System.out.println(e.getMessage());
 * }
 * </pre>
 */
public class ChoiceHandler {
	public static void check(String ch) {
		String regex = "\\d{1,}";

		Pattern p = Pattern.compile(regex);

		Matcher matcher = p.matcher(ch);

		if (!matcher.matches()) {
			throw new InvalidAppointmentException("Choice must be digit!!");
		}
	}
}
