package com.cg.exceptions;

/**
 * InvalidAppointmentException is a custom exception class that extends
 * RuntimeException. It is thrown when an invalid appointment is encountered.
 * 
 * <p>
 * Example usage:
 * </p>
 * 
 * <pre>
 * throw new InvalidAppointmentException("Invalid appointment date");
 * </pre>
 */
public class InvalidAppointmentException extends RuntimeException {
	public InvalidAppointmentException(String msg) {
		super(msg);
	}
}
