package com.cg.exceptions;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * NameHandler is a utility class that provides methods to validate user input.
 * It checks if the provided name is valid according to specified criteria.
 * 
 * <p>
 * Example usage:
 * </p>
 * 
 * <pre>
 * try {
 * 	NameHandler.check("Rashi Gupta");
 * } catch (InvalidAppointmentException e) {
 * 	System.out.println(e.getMessage());
 * }
 * </pre>
 */
public class NameHandler {
	public static void check(String name) {
		String regex = "^[A-Za-z]{1}|[A-Za-z]{1}[A-Za-z0-9\s]{1,}$";

		Pattern p = Pattern.compile(regex);

		Matcher matcher = p.matcher(name);

		if (!matcher.matches()) {
			throw new InvalidAppointmentException("Name should be alpha numeric!!");
		}
	}
}
