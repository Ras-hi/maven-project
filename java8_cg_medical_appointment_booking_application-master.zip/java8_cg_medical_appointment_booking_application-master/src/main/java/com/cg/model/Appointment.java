package com.cg.model;

import com.cg.exceptions.InvalidAppointmentException;

import java.util.Optional;

/**
 * Appointment class represents a medical appointment between a patient and a
 * doctor. It contains information about the patient, doctor, and appointment
 * status.
 * 
 * <p>
 * Example usage:
 * </p>
 * 
 * <pre>
 * Appointment appointment = new Appointment(patient, doctor);
 * System.out.println(appointment.appointmentDetails());
 * </pre>
 */
public class Appointment {
    private Optional<Patient> patient = Optional.empty();
    private Optional<Doctor> doctor = Optional.empty();
    private String status = "Scheduled";
    /**
     * Appointment constructor.
     *
     * @param patient the patient associated with the appointment
     * @param doctor  the doctor associated with the appointment
     * @throws InvalidAppointmentException if the doctor is unavailable
     */
    public Appointment(Patient patient, Doctor doctor) throws InvalidAppointmentException {
        if (doctor.isAvailable()) {
            setDoctor(doctor);
            doctor.setAvailable(false);
            setPatient(patient);
            setStatus("Scheduled");
        } else {
            throw new InvalidAppointmentException("Doctor is unavailable. Appointment scheduling process is failed!");
        }
    }

    /**
     * Gets the patient associated with the appointment.
     *
     * @return an {@code Optional} containing the patient, or an empty {@code Optional} if no patient is set
     */
    public Optional<Patient> getPatient() {
        return this.patient;
    }

    /**
     * Gets the doctor associated with the appointment.
     *
     * @return an {@code Optional} containing the doctor, or an empty {@code Optional} if no doctor is set
     */
    public Optional<Doctor> getDoctor() {
        return this.doctor;
    }

    /**
     * Gets the status of the appointment.
     *
     * @return the status of the appointment
     */
    public String getStatus() {
        return this.status;
    }

    /**
     * Sets the patient for the appointment.
     *
     * @param patient the patient to be set for the appointment
     */
    public void setPatient(Patient patient) {
        this.patient = Optional.ofNullable(patient);
    }

    /**
     * Sets the doctor for the appointment.
     *
     * @param doctor the doctor to be set for the appointment
     */
    public void setDoctor(Doctor doctor) {
        this.doctor = Optional.ofNullable(doctor);
    }

    /**
     * Sets the status of the appointment.
     *
     * @param status the status to be set for the appointment
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Completes the appointment, updating its status and making the doctor available again.
     */
    public void completeAppointment() {
        setStatus("Completed");
        doctor.ifPresent(doc -> {
            doc.setAvailable(true);
            System.out.println("Appointment Completed!");
        });
    }

    /**
     * Provides the details of the appointment.
     *
     * @return a formatted string containing the patient's and doctor's details along with the appointment status
     */
    public String appointmentDetails() {
    	return "Patient's id: " + patient.map(Patient::getId).orElse("N/A") + 
    	        ", and name: " + patient.map(Patient::getName).orElse("N/A") + "\n" +
    	        "Doctor's id: " + doctor.map(Doctor::getId).orElse("N/A") + 
    	        ", and name: " + doctor.map(Doctor::getName).orElse("N/A") + "\n" +
    	        "Appointment status: " + getStatus() + "\n";

    }

}
