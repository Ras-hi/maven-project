package com.cg.model;
/**
 * Doctor class represents a doctor in the system. It extends the User class and
 * adds an availability attribute.
 * 
 * <p>
 * Example usage:
 * </p>
 * 
 * <pre>
 * Doctor doctor = new Doctor("D123", "Dr. Smith");
 * doctor.showProfile();
 * </pre>
 */

public class Doctor extends User {
 private boolean available;


 /**
  * Constructs a Doctor object with the specified id and name.
  *
  * @param id   the unique identifier for the doctor
  * @param name the name of the doctor
  */
 public Doctor(String id, String name) {
     super(id, name);
     setAvailable(true);
 }

 /**
  * Checks if the doctor is available for appointments.
  *
  * @return {@code true} if the doctor is available, {@code false} otherwise
  */
 public boolean isAvailable() {
     return available;
 }

 /**
  * Sets the availability status of the doctor.
  *
  * @param available {@code true} to mark the doctor as available, {@code false} to mark as unavailable
  */
 public void setAvailable(boolean available) {
     this.available = available;
 }

 /**
  * Displays the profile information of the doctor.
  * This includes the doctor's id, name, and availability status.
  */
 @Override
 public void showProfile() {
     System.out.println("Doctor's id: " + this.getId() + ", name: " + this.getName() + ", available: " + this.isAvailable());
 }

}

