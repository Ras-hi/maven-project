package com.cg.model;

import java.util.List;

import java.util.Iterator;

import com.cg.annotations.Security;
import com.cg.exceptions.InvalidAppointmentException;

/**
 * Admin class represents an administrator in the system. It extends the User
 * class and adds a password attribute.
 * 
 * <p>
 * Example usage:
 * </p>
 * 
 * <pre>
 * Admin admin = new Admin("A123", "Rashi Gupta", "password123");
 * admin.showProfile();
 * </pre>
 */
@Security(role = "Admin")
public class Admin extends User{
	private String password;

	/**
	 * Constructor to initialize the Admin object with an ID, name, and password.
	 * 
	 * @param id       The ID of the admin.
	 * @param name     The name of the admin.
	 * @param password The password of the admin.
	 */
	public Admin(String id, String name, String password) {
		super(id, name);
		setPass(password);
	}

	/**
	 * Constructor to initialize the Admin object with a name and password.
	 * 
	 * @param name     The name of the admin.
	 * @param password The password of the admin.
	 */
	public String getPass() {
		return this.password;
	}

	/**
	 * Sets the password of the admin.
	 * 
	 * @param password The password of the admin.
	 */
	public void setPass(String password) {
		this.password = password;
	}

	/**
	 * Displays the profile information of the admin.
	 * <p>
	 * This method prints the admin's name to the console.
	 * </p>
	 */
	@Override
	public void showProfile() {
		System.out.println("Admin's name: "+this.getName());
	}

	/**
	 * Removes a doctor from the list of doctors.
	 * 
	 * @param doctors The list of doctors.
	 * @param doctId  The ID of the doctor to be removed.
	 * @throws InvalidAppointmentException if the admin does not have permission to
	 *                                     remove doctors or if the doctor is not
	 *                                     found.
	 */
	public void removeDoctor(List<Doctor> doctors, String doctId){
		try {
			Class<?> clazz = this.getClass();
			if (clazz.isAnnotationPresent(Security.class)) {
				Security security = clazz.getAnnotation(Security.class);
				if (!"Admin".equals(security.role())) {
					throw new InvalidAppointmentException("Only admins can remove doctors.");
				}
				 boolean found = doctors.stream()
			                .anyMatch(doc -> doc.getId().equalsIgnoreCase(doctId));

			        if (found) {
			            doctors.removeIf(doc -> doc.getId().equalsIgnoreCase(doctId));
			            System.out.println("Doctor with ID " + doctId + " removed.");
			        } else {
			            throw new InvalidAppointmentException("Doctor not found.");
			        }

			} else {
				throw new InvalidAppointmentException("No security annotation found.");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

}