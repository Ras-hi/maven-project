package com.cg.model;

/**
 * Abstract class representing a user with an id and a name.
 * This class serves as a base for specific user types such as Patient and Doctor.
 */
public abstract class User {
    protected String id;
    protected String name;

    /**
     * Constructs a User object with the specified id and name.
     *
     * @param id   the unique identifier for the user
     * @param name the name of the user
     */
    public User(String id, String name) {
        setId(id);
        setName(name);
    }

    /**
     * Gets the unique identifier of the user.
     *
     * @return the user's id
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the unique identifier of the user.
     *
     * @param id the unique identifier to set for the user
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the name of the user.
     *
     * @return the user's name
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the user.
     *
     * @param name the name to set for the user
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Displays the profile information of the user.
     * This method must be implemented by subclasses to provide specific profile details.
     */
    public abstract void showProfile();
}
