package com.cg.model;

public class Patient extends User {
	/**
	 * Constructs a Patient object with the specified id and name.
	 *
	 * @param id   the unique identifier for the patient
	 * @param name the name of the patient
	 */
	public Patient(String id, String name) {
	    super(id, name);
	}

	/**
	 * Displays the profile information of the patient.
	 * This includes the patient's id and name.
	 */
	@Override
	public void showProfile() {
	    System.out.println("Patient's id: " + this.getId() + ", name: " + this.getName());
	}

}
