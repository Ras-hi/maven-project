package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.dto.DoctorDto;
import com.cg.dto.PatientDto;
import com.cg.exceptions.ChoiceHandler;
import com.cg.exceptions.InvalidAppointmentException;
import com.cg.model.*;
import com.cg.ui.Main;

/**
 * AppointmentSystem class manages the appointment scheduling system,
 * including registration of doctors and patients, booking and completing appointments,
 * and displaying information about doctors and patients.
 */
public class AppointmentSystem implements Main {
    
    private Admin admin = null;
    private List<Patient> patients = null;
    private List<Doctor> doctors = null;
    private List<Appointment> appointments = null;
    /**
     * Constructs an AppointmentSystem object and initializes the admin,
     * patients, doctors, and appointments lists.
     */
    public AppointmentSystem() {
        admin = new Admin("000", "System_Admin", "admin456");
        patients = new ArrayList<>();
        doctors = new ArrayList<>();
        appointments = new ArrayList<>();
    }

    /**
     * Validates the admin password and allows the admin to remove a doctor.
     *
     * @param pass the password entered by the admin
     * @param sc   the Scanner object for user input
     */
    public void validateAdminPass(String pass, Scanner sc) {
        try {
            if (admin.getPass().compareTo(pass) == 0) {
                for (Doctor d : doctors) {
                    d.showProfile();
                }
                System.out.println("Enter Doctor's Id:");
                String docId = sc.nextLine();
                ChoiceHandler.check(docId);
                admin.removeDoctor(doctors, docId);
            } else {
                throw new InvalidAppointmentException("Invalid credentials!");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Registers a new doctor in the system.
     *
     * @param doctorDto the data transfer object containing doctor information
     */
    public void registerDoctor(DoctorDto doctorDto) {
        try {
            if (doctorDto instanceof DoctorDto) {
                int id = 0;
                if (!doctors.isEmpty()) {
                    id = doctors.stream().map(Doctor::getId).reduce((first, second) -> second).map(Integer::parseInt).orElse(null);
                }
                id++;
                String new_id = String.valueOf(id);
                String name = doctorDto.getName();
                doctors.add(new Doctor(new_id, name));
                System.out.println("Doctor is added!");
            } else {
                throw new InvalidAppointmentException("Doctor registration failed!");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Registers a new patient in the system.
     *
     * @param patientDto the data transfer object containing patient information
     */
    public void registerPatient(PatientDto patientDto) {
        try {
            if (patientDto instanceof PatientDto) {
                int id = 0;
                if (!patients.isEmpty()) {
                    id = patients.stream().map(Patient::getId).reduce((first, second) -> second).map(Integer::parseInt).orElse(null);
                }
                id++;
                String new_id = String.valueOf(id);
                String name = patientDto.getName();
                patients.add(new Patient(new_id, name));
                System.out.println("Patient is added!");
            } else {
                throw new InvalidAppointmentException("Patient registration failed!");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Books an appointment for a given patient with an available doctor.
     *
     * @param patient the patient for whom the appointment is to be booked
     * @return the booked Appointment object, or null if booking fails
     */
    public Appointment bookAppointment(Patient patient) {
		  try {
			  if (patient != null) {
				  Doctor availableDoctor = doctors.stream().filter(Doctor::isAvailable).findFirst()
						  .orElseThrow(() -> new InvalidAppointmentException("No doctors are currently available."));

				  Appointment appointment = new Appointment(patient, availableDoctor);
				  appointments.add(appointment);
				  System.out.println("Appointment booked.");
				  return appointment;
			  } else {
				  return null;
			  }

		  } catch (Exception e) {
			  System.out.println(e.getMessage());
			  return null;
		  }
	  }

    /**
     * Completes an appointment based on the provided index.
     *
     * @param index the index of the appointment to be completed
     */
    public void completeAppointment(int index) {
        try {
            if (index < 0 || index >= appointments.size()) {
                throw new InvalidAppointmentException("Invalid appointment index.");
            }

            Appointment appointment = appointments.get(index);
            if ("Completed".equals(appointment.getStatus())) {
                throw new InvalidAppointmentException("Appointment already completed.");
            }

            appointment.completeAppointment();
            System.out.println("Appointment is now marked as completed.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Retrieves a list of DoctorDto objects representing the registered doctors.
     *
     * @return a list of DoctorDto objects, or null if no doctors are registered
     */
    private List<DoctorDto> getDoctorDto() {
        List<DoctorDto> tempDocList = new ArrayList<>();
        if (doctors.isEmpty()) {
            return null;
        }
        for (Doctor d : doctors) {
            tempDocList.add(new DoctorDto(d.getName(), d.isAvailable()));
        }
        return tempDocList;
    }

    /**
     * Displays the profiles of all registered doctors.
     *
     * @throws InvalidAppointmentException if no doctors are registered
     */
    public void showAllDoctors() {
		  try {
			  List<DoctorDto> tempDocList = this.getDoctorDto();
			  if (tempDocList != null) {
				  tempDocList.stream().forEach(DoctorDto::showProfile);
			  } else {
				  throw new InvalidAppointmentException("There is no registered doctor!");
			  }
		  } catch (Exception e) {
			  System.out.println(e.getMessage());
		  }
	  }

    /**
     * Displays the details of all scheduled appointments.
     *
     * @throws InvalidAppointmentException if no appointments are scheduled
     */
    public void showAllAppointments() throws InvalidAppointmentException {
        if (!appointments.isEmpty()) {
        	for(int i=0;i<appointments.size();i++) {
				System.out.print(i+1);
				System.out.println(" -> "+appointments.get(i).appointmentDetails());
			}
        } else {
            throw new InvalidAppointmentException("There is no appointment scheduled!");
        }
    }

    /**
     * Retrieves a list of PatientDto objects representing the registered patients.
     *
     * @return a list of PatientDto objects, or null if no patients are registered
     */
    private List<PatientDto> getPatientDto() {
        List<PatientDto> tempList = new ArrayList<>();
        if (patients.isEmpty()) {
            return null;
        }
        for (Patient p : patients) {
            tempList.add(new PatientDto(p.getName()));
        }
        return tempList;
    }

    /**
     * Displays the profiles of all registered patients.
     *
     * @throws InvalidAppointmentException if no patients are registered
     */
    public void showAllPatients() {
		  try {
			  List<PatientDto> tempList = this.getPatientDto();
			  if (tempList != null) {
				  tempList.stream().forEach(PatientDto::showProfile);
			  } else {
				  throw new InvalidAppointmentException("There is no registered patient!");
			  }
		  } catch (Exception e) {
			  System.out.println(e.getMessage());
		  }
	  }

    /**
     * Retrieves the list of registered patients.
     *
     * @return the list of patients
     */
    public List<Patient> getPatientList() {
        return patients;
    }

    /**
     * Retrieves the list of registered doctors.
     *
     * @return the list of doctors
     */
    public List<Doctor> getDoctorList() {
        return doctors;
    }
}
